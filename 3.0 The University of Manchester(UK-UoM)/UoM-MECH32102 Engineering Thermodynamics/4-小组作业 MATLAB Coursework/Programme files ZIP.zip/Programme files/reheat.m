function varargout = reheat(varargin)
% REHEAT MATLAB code for reheat.fig
%      REHEAT, by itself, creates a new REHEAT or raises the existing
%      singleton*.
%
%      H = REHEAT returns the handle to a new REHEAT or the handle to
%      the existing singleton*.
%
%      REHEAT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in REHEAT.M with the given input arguments.
%
%      REHEAT('Property','Value',...) creates a new REHEAT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before reheat_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to reheat_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help reheat

% Last Modified by GUIDE v2.5 07-Sep-2012 09:23:09

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @reheat_OpeningFcn, ...
                   'gui_OutputFcn',  @reheat_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before reheat is made visible.
function reheat_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to reheat (see VARARGIN)

% Choose default command line output for reheat
handles.output = hObject;
%Create header for output spreadsheet
fid = fopen('output_sheet_reheat_rankine.csv','w');
fprintf(fid,'p3[kPa],T3[�C],p6[kPa],p5[kPa],T5[�C], Q(4-5)[kJ/kg],Qin[kJ/kg],Qout[kJ/kg],WT[kJ/kg],WP[kJ/kg],Efficiency[%%],Quality 6[%%],H1[kJ/kg],H2[kJ/kg],H3[kJ/kg],H4[kJ/kg],H5[kJ/kg],H6[kJ/kg]\n');

fclose(fid);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes reheat wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = reheat_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in calculate_pushbutton.
function calculate_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to calculate_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% handles.fileName=uigetfile('saturated.xlsx');
p3 = get(handles.p3_editText,'String');
T3 = get(handles.T3_editText,'String');
p6 = get(handles.p6_editText,'String');
p5 = get(handles.p5_editText,'String');
T5 = get(handles.T5_editText,'String');
PumpEff = get(handles.Pump1_editText,'String');
TurbineEff = get(handles.TurbineEff_editText,'String');

% some basic error checking

% the reheat pressure cannot be greater than the turbine inlet pressure
if str2num(p5) > str2num(p3)
    errmsg = sprintf("P5 (%.0f kPa) cannot be greater than P3 (%.0f kPa).",str2num(p5),str2num(p3));
    f = errordlg(errmsg,"Error",'modal');
    error(errmsg);
end

saturated=xlsread('saturated.xlsx');
% water=xlsread('compressed_water1.xlsx','B2:H10');
% temp_w=[20	40	80	100	140	180	200	220	223.9]';
% pressure_w=[2.5e3 5e3 7.5e3	10e3 15e3 20e3 25e3];
pressure=saturated(:,1);
temp=saturated(:,2);
hf=saturated(:,6);
hfg=saturated(:,7);
hg1=saturated(:,8);
sf=saturated(:,9);
sfg=saturated(:,10);
sg1=saturated(:,11);
pressure_super=[0.006112 0.01 0.05 0.1 0.5 0.75	1 1.01325 1.5 2	3 ...
    4	5	6	7	8	9	10	15	20	30	40	50	60	70	80	90	100	...
    110	120	130	140	150	160	170	180	190	200	210	220	221.2]';
Ts=[0.01	7	32.9	45.8	81.3	91.8	99.6	100	111.4	120.2	...
    133.5	143.6	151.8	158.8	165	170.4	175.4	179.9	198.3	212.4	...
    233.8	250.3	263.9	275.6	285.8	295	303.3	311	318	324.6	330.8	...
    336.6	342.1	347.3	352.3	357	361.4	365.7	369.8	373.7	374.15]';
T=[50 100 150 200 250	300	350	375	400	425	450	500	600	700];
hg=[2501	2514	2561	2584	2645	2662	2675	2676	2693	...
    2707	2725	2739	2749	2757	2764	2769	2774	2778	...
    2792	2799	2803	2801	2794	2784	2772	2758	2743	...
    2725	2705	2685	2662	2638	2611	2582	2548	2510	...
    2466	2411	2336	2178	2084]';
sg=[9.155	8.974	8.394	8.149	7.593	7.456	7.359	7.355	7.223	...
    7.127	6.993	6.897	6.822	6.761	6.709	6.663	6.623	6.586	...
    6.445	6.34	6.186	6.07	5.973	5.89	5.814	5.744	5.679	...
    5.615	5.553	5.493	5.433	5.373	5.312	5.248	5.181	5.108	...
    5.027	4.928	4.803	4.552	4.406]';

% Raise an error if p3 is greater than the critical pressure
if str2num(p3) > max(pressure_super)*100
    errmsg = sprintf("Pressures above the critical pressure (%.2f kPa) are not supported.",max(pressure_super)*100);
    f = errordlg(errmsg,"Error",'modal');
    error(errmsg);
end

h_s=xlsread('superheated_h.xlsx','B2:O42');
s_s=xlsread('superheated_s.xlsx','C2:P42');

T31  = interp1(pressure,temp,str2num(p3)/100);
sf31 =interp1(pressure,sf,str2num(p3)/100);
sg31 = interp1(pressure,sg1,str2num(p3)/100);
T6   = interp1(pressure,temp,str2num(p6)/100);
hf6  = interp1(pressure,hf,str2num(p6)/100);
hfg6 = interp1(pressure,hfg,str2num(p6)/100);
sf6  = interp1(pressure,sf,str2num(p6)/100);
sg6  = interp1(pressure,sg1,str2num(p6)/100);
sfg6 = interp1(pressure,sfg,str2num(p6)/100);    
hf4  = interp1(pressure,hf,str2num(p5)/100);
hfg4 = interp1(pressure,hfg,str2num(p5)/100);
sf4  = interp1(pressure,sf,str2num(p5)/100);
sg4  = interp1(pressure,sg1,str2num(p5)/100);
sfg4 = interp1(pressure,sfg,str2num(p5)/100);   
% sw_p3 = interp2(temp_w,pressure_w,water',temp_w,p3);
% T2=interp1(sw_p3',temp_w,sf4)+15;

% interpolating row wise, to give a row of h and s values at a given
% pressure
h_p3=interp2(pressure_super,T,h_s',str2num(p3)/100,T);
s_p3=interp2(pressure_super,T,s_s',str2num(p3)/100,T);

% injecting saturated vapour values
Ts_p3=interp1(pressure_super,Ts,str2num(p3)/100);
hg_p3=interp1(pressure_super,hg,str2num(p3)/100);
sg_p3=interp1(pressure_super,sg,str2num(p3)/100);
Tnew=[T Ts_p3];
Tnew=sort(Tnew);

for b=1:length(T)
   if Tnew(b)==Ts_p3
      n=b;
      break;
   end
end

% I think this is injecting the hg and sg values into the 
%if h_p3(n)==1
if isnan(h_p3(n))
    h_p3(n)=hg_p3;
    s_p3(n)=sg_p3;
    h_p3(n+1:end+1) = h_p3(n:end);
    h_p3(n+1)=h_p3(n)+(Tnew(n+1)-Tnew(n))*(h_p3(n+2)-h_p3(n))/(Tnew(n+2)-Tnew(n));
    s_p3(n+1:end+1) = s_p3(n:end);
    s_p3(n+1)=s_p3(n)+(Tnew(n+1)-Tnew(n))*(s_p3(n+2)-s_p3(n))/(Tnew(n+2)-Tnew(n));
else
    h_p3(n+1:end+1) = h_p3(n:end);
    h_p3(n)=hg_p3;
    s_p3(n+1:end+1) = s_p3(n:end);
    s_p3(n)=sg_p3;
end

% warn if the inlet temperature is less than the saturation temperature at
% that pressure
if str2num(T3) < Ts_p3
    errmsg = sprintf("T3 is below the saturation temperature (%3.2f C) at this pressure (%.2f kPa).",Ts_p3,str2num(p3));
    f = errordlg(errmsg,"Warning",'modal');
end


% replace invalid values
idxgood=~(isnan(h_p3) | isnan(s_p3));
h_p3=h_p3(idxgood);
s_p3=s_p3(idxgood);
Tnew=Tnew(idxgood);

h3=interp1(Tnew,h_p3,str2num(T3),"linear","extrap");
s3=interp1(Tnew,s_p3,str2num(T3),"linear","extrap");
p1=str2num(p6);
%State4
s4=s3;
p4=str2num(p5);
h_p4=interp2(pressure_super,T,h_s',p4/100,T);
s_p4=interp2(pressure_super,T,s_s',p4/100,T);

Ts_p4=interp1(pressure_super,Ts,p4/100);
hg_p4=interp1(pressure_super,hg,p4/100);
sg_p4=interp1(pressure_super,sg,p4/100);
Tnew4=[T Ts_p4];
Tnew4=sort(Tnew4);

for b=1:length(T)
   if Tnew4(b)==Ts_p4
      n=b;
      break;
   end
end

if isnan(h_p3(n))
%if h_p4(n)==1
    h_p4(n)=hg_p4;
    s_p4(n)=sg_p4;
    h_p4(n+1:end+1) = h_p4(n:end);
    h_p4(n+1)=h_p4(n)+(Tnew4(n+1)-Tnew4(n))*(h_p4(n+2)-h_p4(n))/(Tnew4(n+2)-Tnew4(n));
    s_p4(n+1:end+1) = s_p4(n:end);
    s_p4(n+1)=s_p4(n)+(Tnew4(n+1)-Tnew4(n))*(s_p4(n+2)-s_p4(n))/(Tnew4(n+2)-Tnew4(n));
else
    h_p4(n+1:end+1) = h_p4(n:end);
    h_p4(n)=hg_p4;
    s_p4(n+1:end+1) = s_p4(n:end);
    s_p4(n)=sg_p4;
end
c=1;
for ty=1:length(s_p4)
    if s_p4(c)==1
        c=c+1;
    else
        s_p4=s_p4(c:end);
        h_p4=h_p4(c:end);
        Tnew4=Tnew4(c:end);
        break;
    end
end




% replace invalid values
idxgood=~(isnan(h_p4) | isnan(s_p4));
h_p4=h_p4(idxgood);
s_p4=s_p4(idxgood);
Tnew4=Tnew4(idxgood);


h4=interp1(s_p4,h_p4,s4,'linear','extrap');
T4=interp1(s_p4,Tnew4,s4,'linear','extrap');

% Finding h5 and s6
h_p5=interp2(pressure_super,T,h_s',str2num(p5)/100,T);
s_p5=interp2(pressure_super,T,s_s',str2num(p5)/100,T);
Ts_p5=interp1(pressure_super,Ts,str2num(p5)/100);
hg_p5=interp1(pressure_super,hg,str2num(p5)/100);
sg_p5=interp1(pressure_super,sg,str2num(p5)/100);
Tnew1=[T Ts_p5];
Tnew1=sort(Tnew1);
for b=1:length(T)
   if Tnew1(b)==Ts_p5
      n=b;
      break;
   end
end

%if h_p5(n)==1
if isnan(h_p5)
    h_p5(n)=hg_p5;
    s_p5(n)=sg_p5;
    h_p5(n+1:end+1) = h_p5(n:end);
    h_p5(n+1)=h_p5(n)+(Tnew1(n+1)-Tnew1(n))*(h_p5(n+2)-h_p5(n))/(Tnew1(n+2)-Tnew1(n));
    s_p5(n+1:end+1) = s_p5(n:end);
    s_p5(n+1)=s_p5(n)+(Tnew1(n+1)-Tnew1(n))*(s_p5(n+2)-s_p5(n))/(Tnew1(n+2)-Tnew1(n));
else
    h_p5(n+1:end+1) = h_p5(n:end);
    h_p5(n)=hg_p5;
    s_p5(n+1:end+1) = s_p5(n:end);
    s_p5(n)=sg_p5;
end

% the reheat temperature cannot be less than the temperature at state 4
% (otherwise our boiler is extracting heat)
if str2num(T5) < T4
    errmsg = sprintf("T5 (%.2f C) is below the temperature  at state 4 (%.2f C).",str2num(T5),T4);
    f = errordlg(errmsg,"Warning",'modal');
    %error(errmsg);
end

% replace invalid values
idxgood=~(isnan(h_p5) | isnan(s_p5));
h_p5=h_p5(idxgood);
s_p5=s_p5(idxgood);
Tnew1=Tnew1(idxgood);

h5=interp1(Tnew1,h_p5,str2num(T5),"linear","extrap");
s5=interp1(Tnew1,s_p5,str2num(T5),"linear","extrap");

% -------------------------------------
h1=hf6;
p2=str2num(p3);
s6=s5;
x6=(s6-sf6)/sfg6;
h6=hf6+x6*hfg6;
% h2=h1+0.001*(p2-p1);
h4new=h3-(h3-h4)*str2num(TurbineEff)*0.01;
h6new=h5-(h5-h6)*str2num(TurbineEff)*0.01;
x4new=(h4new-hf4)/hfg4;
WT=sprintf('%0.2f',(h3-h4new+h5-h6new));
WP=sprintf('%0.2f',-(0.001*(p2-p1))/(str2num(PumpEff)*0.01));
% h2=h1+0.001*(p2-p1);
h2=h1+(0.001*(p2-p1))/(str2num(PumpEff)*0.01);
x6new=(h6new-hf6)/hfg6;
Q23=sprintf('%0.2f',h3-h2);
Q45=sprintf('%0.2f',h5-h4new);
Qin=sprintf('%0.2f',h3-h2+h5-h4new);
Qout=sprintf('%0.2f',h1-h6new);
Quality=sprintf('%0.2f',x6new*100);
W=sprintf('%0.2f',(h3-h4new+h5-h6new)-(0.001*(p2-p1))/(str2num(PumpEff)*0.01));  %WT+WP
Eff=sprintf('%0.2f',((h3-h4new+h5-h6new)-(0.001*(p2-p1))/(str2num(PumpEff)*0.01))*100/(h3-h2+h5-h4new));   %W*100/Qin
set(handles.Q23_text,'String',Q23);
set(handles.Q45_text,'String',Q45);
set(handles.Qin_staticText,'String',Qin);
set(handles.Qout_text,'String',Qout);
set(handles.WT_text,'String',WT);
set(handles.WP_text,'String',WP);
set(handles.Eff_text,'String',Eff);
set(handles.Quality_text,'String',Quality);
axes(handles.axes2);
pump=str2num(PumpEff)*0.01;
turbine=str2num(TurbineEff)*0.01;
% plot(handles.axes2,sf,temp,'k');
% hold on;
% plot(handles.axes2,sg1,temp,'k');
plot(sf,temp,'k');
hold on;
plot(sg1,temp,'k');
xlabel('Entropy, s(kJ/kgK)');
ylabel(['Temperature (' 176 'C)']);
plot([sf6 sg6],[T6 T6],'LineWidth',2);
plot([sf6 sf6],[T6 T6+30],'-o','LineWidth',2);
if pump~=1
plot([sf6 (sf6+sfg6*(1-pump)-0.5)],[T6 T6+115],'-.or','LineWidth',2);
end
plot([sf6 sf31],[T6+20 T31],'LineWidth',2);
plot([sf31 sg31],[T31 T31],'LineWidth',2);
plot([s3 s3],[T4 str2num(T3)],'-o','LineWidth',2);
if turbine~=1
plot([sf4+x4new*sfg4 s3],[T4+25 str2num(T3)],'-.or','LineWidth',2);
end
% plot([0.5*(sg31+s3) s3],[0.25*(3*T31+T3) T3]);

x=[sg31 0.5*(sg31+s3) s3];
y=[T31 0.25*(3*T31+str2num(T3)) str2num(T3)];
coef=polyfit(x,y,2);
y1 = polyval(coef, x);
plot(x,y1,':','LineWidth',2);
x2=[s4 0.5*(s4+s5) s5];
y2=[T4 0.25*(3*T4+str2num(T5)) str2num(T5)];
coef=polyfit(x2,y2,2);
y3 = polyval(coef, x2);
plot(x2,y3,':','LineWidth',2);
plot([s5 s5],[T6 str2num(T5)],'-o','LineWidth',2);
if turbine~=1
plot([sf6+x6new*sfg6 s5],[T6 str2num(T5)],'-.or','LineWidth',2);
end
hold off;
H1=num2str(h1);
H2=num2str(h2);
H3=num2str(h3);
H4=num2str(h4new);
H5=num2str(h5);
H6=num2str(h6new);
%Append a row of results to output_sheet.csv for this calculation
fid = fopen('output_sheet_reheat_rankine.csv','a+');
fprintf(fid, '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',p3,T3,p6,p5,T5,Q45,Qin,Qout,WT,WP,Eff,Quality,H1,H2,H3,H4,H5,H6);
fclose(fid);
guidata(hObject, handles);

function p3_editText_Callback(hObject, eventdata, handles)
% hObject    handle to p3_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p3_editText as text
%        str2double(get(hObject,'String')) returns contents of p3_editText as a double

%store the contents of input1_editText as a string. if the string
%is not a number then input will be empty
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function p3_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p3_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function T3_editText_Callback(hObject, eventdata, handles)
% hObject    handle to T3_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of T3_editText as text
%        str2double(get(hObject,'String')) returns contents of T3_editText as a double

%store the contents of input1_editText as a string. if the string
%is not a number then input will be empty
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function T3_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to T3_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function p6_editText_Callback(hObject, eventdata, handles)
% hObject    handle to p6_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p6_editText as text
%        str2double(get(hObject,'String')) returns contents of p6_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function p6_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p6_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Pump1_editText_Callback(hObject, eventdata, handles)
% hObject    handle to Pump1_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Pump1_editText as text
%        str2double(get(hObject,'String')) returns contents of Pump1_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function Pump1_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Pump1_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TurbineEff_editText_Callback(hObject, eventdata, handles)
% hObject    handle to TurbineEff_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TurbineEff_editText as text
%        str2double(get(hObject,'String')) returns contents of TurbineEff_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function TurbineEff_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TurbineEff_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function p5_editText_Callback(hObject, eventdata, handles)
% hObject    handle to p5_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p5_editText as text
%        str2double(get(hObject,'String')) returns contents of p5_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function p5_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p5_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function T5_editText_Callback(hObject, eventdata, handles)
% hObject    handle to T5_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of T5_editText as text
%        str2double(get(hObject,'String')) returns contents of T5_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function T5_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to T5_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% axes(hObject)
% imshow('reheat_diagram.png')
axes(hObject)
hold on;
image(imread('reheat_diagram.png'))
set(gca , 'XTick' , [ ]);
set(gca , 'YTick', [ ]);
set(gca , 'ZTick' , [ ]);
% Hint: place code in OpeningFcn to populate axes3


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
