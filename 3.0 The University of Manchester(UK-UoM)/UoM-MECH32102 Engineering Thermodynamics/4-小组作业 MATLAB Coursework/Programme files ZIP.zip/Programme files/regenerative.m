function varargout = regenerative(varargin)
% REGENERATIVE MATLAB code for regenerative.fig
%      REGENERATIVE, by itself, creates a new REGENERATIVE or raises the existing
%      singleton*.
%
%      H = REGENERATIVE returns the handle to a new REGENERATIVE or the handle to
%      the existing singleton*.
%
%      REGENERATIVE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in REGENERATIVE.M with the given input arguments.
%
%      REGENERATIVE('Property','Value',...) creates a new REGENERATIVE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before regenerative_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to regenerative_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help regenerative

% Last Modified by GUIDE v2.5 11-Sep-2012 17:00:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @regenerative_OpeningFcn, ...
                   'gui_OutputFcn',  @regenerative_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before regenerative is made visible.
function regenerative_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to regenerative (see VARARGIN)

% Choose default command line output for regenerative
handles.output = hObject;
fid = fopen('output_sheet_regenerative.csv','w');
fprintf(fid,'p5[kPa],T5[�C],p7[kPa],p6[kPa],m6/m5,Qin[kJ/kg],Qout[kJ/kg],WT[kJ/kg],Wpump1[kJ/kg],Wpump2[kJ/kg],Efficiency[%%],Quality 7[%%],H1[kJ/kg],H2[kJ/kg],H3[kJ/kg],H4[kJ/kg],H5[kJ/kg],H6[kJ/kg],H7[kJ/kg]\n');

fclose(fid);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes regenerative wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = regenerative_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in calculate_pushbutton.
function calculate_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to calculate_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% handles.fileName=uigetfile('saturated.xlsx');
p5 = get(handles.p5_editText,'String');
T5 = get(handles.T5_editText,'String');
p6 = get(handles.p6_editText,'String');
p7 = get(handles.p7_editText,'String');

% P6 has to be between P5 and P7
% the reheat pressure cannot be greater than the turbine inlet pressure
if str2num(p6) > str2num(p5) || str2num(p6) < str2num(p7)
    errmsg = sprintf("P6 (%.0f kPa) must be between P5 and P7.",str2num(p6));
    f = errordlg(errmsg,"Error",'modal');
    error(errmsg);
end

PumpEff = get(handles.Pump1_editText,'String');
TurbineEff = get(handles.TurbineEff_editText,'String');

saturated=xlsread('saturated.xlsx');
% water=xlsread('compressed_water1.xlsx','B2:H10');
% temp_w=[20	40	80	100	140	180	200	220	223.9]';
% pressure_w=[2.5e3 5e3 7.5e3	10e3 15e3 20e3 25e3];
pressure=saturated(:,1);
temp=saturated(:,2);
hf=saturated(:,6);
hfg=saturated(:,7);
hg1=saturated(:,8);
sf=saturated(:,9);
sfg=saturated(:,10);
sg1=saturated(:,11);
pressure_super=[0.006112 0.01 0.05 0.1 0.5 0.75	1 1.01325 1.5 2	3 ...
    4	5	6	7	8	9	10	15	20	30	40	50	60	70	80	90	100	...
    110	120	130	140	150	160	170	180	190	200	210	220	221.2]';
Ts=[0.01	7	32.9	45.8	81.3	91.8	99.6	100	111.4	120.2	...
    133.5	143.6	151.8	158.8	165	170.4	175.4	179.9	198.3	212.4	...
    233.8	250.3	263.9	275.6	285.8	295	303.3	311	318	324.6	330.8	...
    336.6	342.1	347.3	352.3	357	361.4	365.7	369.8	373.7	374.15]';
T=[50 100 150 200 250	300	350	375	400	425	450	500	600	700];
hg=[2501	2514	2561	2584	2645	2662	2675	2676	2693	...
    2707	2725	2739	2749	2757	2764	2769	2774	2778	...
    2792	2799	2803	2801	2794	2784	2772	2758	2743	...
    2725	2705	2685	2662	2638	2611	2582	2548	2510	...
    2466	2411	2336	2178	2084]';
sg=[9.155	8.974	8.394	8.149	7.593	7.456	7.359	7.355	7.223	...
    7.127	6.993	6.897	6.822	6.761	6.709	6.663	6.623	6.586	...
    6.445	6.34	6.186	6.07	5.973	5.89	5.814	5.744	5.679	...
    5.615	5.553	5.493	5.433	5.373	5.312	5.248	5.181	5.108	...
    5.027	4.928	4.803	4.552	4.406]';

% Raise an error if p3 is greater than the critical pressure
if str2num(p5) > max(pressure_super)*100
    errmsg = sprintf("Pressures above the critical pressure (%.2f kPa) are not supported.",max(pressure_super)*100);
    f = errordlg(errmsg,"Error",'modal');
    error(errmsg);
end

h_s=xlsread('superheated_h.xlsx','B2:O42');
s_s=xlsread('superheated_s.xlsx','C2:P42');

ps=[0.006112 0.008719 0.01227 0.01704 0.02337 0.03166 0.04242 0.05622 0.07375 ...
    0.09582  0.1233   0.1574  0.1992  0.2501  0.3116  0.3855  0.4736  0.5780 ...
    0.7011   0.8453  1.01325  1.208   1.433   1.691   1.985   2.321   2.701 ...
    3.131    3.614    4.155   4.760   6.181   7.920   10.03   12.55   15.55 ...
    19.08    23.20    27.98   33.48   39.78   46.94   55.05   64.19   74.45 ...
    85.92    112.9    146.1   186.7   210.5   221.2];
vf=0.01*[0.10002 0.10001 0.10003 0.10010 0.10018 0.10030 0.10044 0.10060 0.10079 ...
         0.10099 0.1012  0.1015  0.1017  0.1020  0.1023  0.1026  0.1029  0.1032 ...
         0.1036  0.1040  0.1044  0.1048  0.1052  0.1056  0.1060 0.1065   0.1070 ...
         0.1075  0.1080  0.1085  0.1091  0.1102  0.1114  0.1128  0.1142  0.1157 ...
         0.1173  0.1190  0.1209  0.1229  0.1251  0.1276  0.1302  0.1332  0.1366 ...
         0.1404  0.1499  0.1639  0.1894  0.2225 0.317];
T51  = interp1(pressure,temp,str2num(p5)/100);
sf51 =interp1(pressure,sf,str2num(p5)/100);
sg51 = interp1(pressure,sg1,str2num(p5)/100);
T6   = interp1(pressure,temp,str2num(p6)/100);
hf6  = interp1(pressure,hf,str2num(p6)/100);
hfg6 = interp1(pressure,hfg,str2num(p6)/100);
sf6  = interp1(pressure,sf,str2num(p6)/100);
sg6  = interp1(pressure,sg1,str2num(p6)/100);
sfg6 = interp1(pressure,sfg,str2num(p6)/100);
T7   = interp1(pressure,temp,str2num(p7)/100);
hf7  = interp1(pressure,hf,str2num(p7)/100);
hfg7 = interp1(pressure,hfg,str2num(p7)/100);
sf7 = interp1(pressure,sf,str2num(p7)/100);
sg7  = interp1(pressure,sg1,str2num(p7)/100);
sfg7 = interp1(pressure,sfg,str2num(p7)/100);    
        
% sw_p3 = interp2(temp_w,pressure_w,water',temp_w,p3);
% T2=interp1(sw_p3',temp_w,sf4)+15;


%State1
p1=str2num(p7);
h1=hf7;
s1=sf7;
v1=interp1(ps,vf',p1/100);
%State2
p2=str2num(p6);
WP1=v1*(p2-p1)/(str2num(PumpEff)*0.01);
h2=h1+WP1;
s2=s1;
%State3
p3=p2;
h3=hf6;
s3=sf6;
v3=interp1(ps,vf,p3/100);
%State4
p4=str2num(p5);
s4=s3;
WP2=v3*(p4-p3)/(str2num(PumpEff)*0.01);
h4=h3+WP2;
%State5
h_p5=interp2(pressure_super,T,h_s',str2num(p5)/100,T);
s_p5=interp2(pressure_super,T,s_s',str2num(p5)/100,T);
Ts_p5=interp1(pressure_super,Ts,str2num(p5)/100);
hg_p5=interp1(pressure_super,hg,str2num(p5)/100);
sg_p5=interp1(pressure_super,sg,str2num(p5)/100);
Tnew=[T Ts_p5];
Tnew=sort(Tnew);

for b=1:length(T)
   if Tnew(b)==Ts_p5
      n=b;
      break;
   end
end


%if h_p5(n)==1
if isnan(h_p5(n))
    h_p5(n)=hg_p5;
    s_p5(n)=sg_p5;
    h_p5(n+1:end+1) = h_p5(n:end);
    h_p5(n+1)=h_p5(n)+(Tnew(n+1)-Tnew(n))*(h_p5(n+2)-h_p5(n))/(Tnew(n+2)-Tnew(n));
    s_p5(n+1:end+1) = s_p5(n:end);
    s_p5(n+1)=s_p5(n)+(Tnew(n+1)-Tnew(n))*(s_p5(n+2)-s_p5(n))/(Tnew(n+2)-Tnew(n));
else
    h_p5(n+1:end+1) = h_p5(n:end);
    h_p5(n)=hg_p5;
    s_p5(n+1:end+1) = s_p5(n:end);
    s_p5(n)=sg_p5;
end

% replace invalid values
idxgood=~(isnan(h_p5) | isnan(s_p5));
h_p5=h_p5(idxgood);
s_p5=s_p5(idxgood);
Tnew=Tnew(idxgood);

h5=interp1(Tnew,h_p5,str2num(T5),"linear","extrap");
s5=interp1(Tnew,s_p5,str2num(T5),"linear","extrap");
%State6
s6=s5;
h_p6=interp2(pressure_super,T,h_s',str2num(p6)/100,T);
s_p6=interp2(pressure_super,T,s_s',str2num(p6)/100,T);
Ts_p6=interp1(pressure_super,Ts,str2num(p6)/100);
hg_p6=interp1(pressure_super,hg,str2num(p6)/100);
sg_p6=interp1(pressure_super,sg,str2num(p6)/100);
Tnew6=[T Ts_p6];
Tnew6=sort(Tnew6);
for b=1:length(T)
   if Tnew6(b)==Ts_p6
      n=b;
      break;
   end
end
if h_p6(n)==1
    h_p6(n)=hg_p6;
    s_p6(n)=sg_p6;
    h_p6(n+1:end+1) = h_p6(n:end);
    h_p6(n+1)=h_p6(n)+(Tnew6(n+1)-Tnew6(n))*(h_p6(n+2)-h_p6(n))/(Tnew6(n+2)-Tnew6(n));
    s_p6(n+1:end+1) = s_p6(n:end);
    s_p6(n+1)=s_p6(n)+(Tnew6(n+1)-Tnew6(n))*(s_p6(n+2)-s_p6(n))/(Tnew6(n+2)-Tnew6(n));
else
    h_p6(n+1:end+1) = h_p6(n:end);
    h_p6(n)=hg_p6;
    s_p6(n+1:end+1) = s_p6(n:end);
    s_p6(n)=sg_p6;
end
c=1;
for t=1:length(s_p6)
    if s_p6(c)==1;
        c=c+1;
    else
        s_p6=s_p6(c:end);
        h_p6=h_p6(c:end);
        Tnew6=Tnew6(c:end);
        break;
    end
end

% replace invalid values
idxgood=~(isnan(h_p6) | isnan(s_p6));
h_p6=h_p6(idxgood);
s_p6=s_p6(idxgood);
Tnew6=Tnew6(idxgood);

h6=interp1(s_p6,h_p6,s6,"linear","extrap");
T6=interp1(s_p6,Tnew6,s6,"linear","extrap");

%State7
s7=s5;
x7=(s7-sf7)/sfg7;
h7=hf7+x7*hfg7;
% h2=h1+0.001*(p2-p1);
h7new=h5-(h5-h7)*str2num(TurbineEff)*0.01;
h6new=h5-(h5-h6)*str2num(TurbineEff)*0.01;

WT=sprintf('%0.2f',(h5-h6new+(1-(h3-h2)/(h6new-h2))*(h6new-h7new)));
Wpump1=sprintf('%0.2f',WP1);
Wpump2=sprintf('%0.2f',WP2);
y=sprintf('%0.2f',(h3-h2)/(h6new-h2));

x7new=(h7new-hf7)/hfg7;
Qin=sprintf('%0.2f',h5-h4);
Qout=sprintf('%0.2f',(1-(h3-h2)/(h6new-h2))*(h7new-h1));
Quality=sprintf('%0.2f',x7new*100);
W=sprintf('%0.2f',h5-h4-(1-(h3-h2)/(h6new-h2))*(h7new-h1));  %Qin-Qout
Eff=sprintf('%0.2f',(1-((1-(h3-h2)/(h6new-h2))*(h7new-h1))/(h5-h4))*100);   %(1-Qout/Qin)*100

% Qin=num2str(h3-h2);
% Qout=num2str(h1-h4);
% WT=num2str(h3-h4);
% WP=num2str(h1-h2);
% Quality=num2str(x4*100);
% W=num2str(h3-h4+h1-h2);  %WT+WP
% Eff=num2str((h3-h4+h1-h2)*100/(h3-h2));   %W*100/Qin
% need to convert the answer back into String type to display it
set(handles.y_text,'String',y);
set(handles.Qin_staticText,'String',Qin);
set(handles.Qout_text,'String',Qout);
set(handles.WT_text,'String',WT);
set(handles.WP1_text,'String',Wpump1);
set(handles.WP2_text,'String',Wpump2);
set(handles.Eff_text,'String',Eff);
set(handles.Quality_text,'String',Quality);
pump=str2num(PumpEff)*0.01;
turbine=str2num(TurbineEff)*0.01;
%Plotting graph
 axes(handles.axes2);
 plot(sf,temp,'k');
 hold on;
 plot(sg1,temp,'k');
 xlabel('Entropy, s(kJ/kgK)');
 ylabel(['Temperature (' 176 'C)']);
 plot([sf7 sg7],[T7 T7],'LineWidth',2);
 %First loop
 plot([sf7 sf7],[T7 T7+20],'-o','LineWidth',2);
 if pump~=1
plot([sf7 (sf7+sfg7*(1-pump)-0.7)],[T7 T7+75],'-.or','LineWidth',2);
end
 plot([sf7 sf6],[T7+20 Ts_p6],'LineWidth',2);
 plot([sf6 sg6],[Ts_p6 Ts_p6],'LineWidth',2);
 %Second loop
 plot([sf6 sf6],[Ts_p6 Ts_p6+20],'-o','LineWidth',2);
  if pump~=1
plot([sf6 (sf6+sfg6*(1-pump)-0.5)],[Ts_p6 Ts_p6+50],'-.or','LineWidth',2);
end
 plot([sf6 sf51],[Ts_p6+20 T51],'LineWidth',2);
 plot([sf51 sg51],[T51 T51],'LineWidth',2);
plot([s5 s5],[T7 str2num(T5)],'-o','LineWidth',2);
% % plot([0.5*(sg31+s3) s3],[0.25*(3*T31+T3) T3]);
% 
 x=[sg51 0.5*(sg51+s5) s5];
 y5=[T51 0.25*(3*T51+str2num(T5)) str2num(T5)];
 coef=polyfit(x,y5,2);
 y1 = polyval(coef, x);
 plot(x,y1,':','LineWidth',2);
 x2=[sg6 0.5*(sg6+s6+0.4) s6+0.4];
 y2=[Ts_p6 0.25*(3*Ts_p6+T6+80) T6+80];
 coef=polyfit(x2,y2,2);
 y3 = polyval(coef, x2);
 plot(x2,y3,':','LineWidth',2);
 if turbine~=1
plot([sf7+x7new*sfg7 s5],[T7 str2num(T5)],'-.or','LineWidth',2);
 end
% plot([s5 s5],[T6 str2num(T5)],'-o');
 hold off;
H1=num2str(h1);
H2=num2str(h2);
H3=num2str(h3);
H4=num2str(h4);
H5=num2str(h5);
H6=num2str(h6new);
H7=num2str(h7new);
%Append a row of results to output_sheet.csv for this calculation
fid = fopen('output_sheet_regenerative.csv','a+');
fprintf(fid, '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',p5,T5,p7,p6,y,Qin,Qout,WT,Wpump1,Wpump2,Eff,Quality,H1,H2,H3,H4,H5,H6,H7);
fclose(fid);
guidata(hObject, handles);

function p5_editText_Callback(hObject, eventdata, handles)
% hObject    handle to p6_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p6_editText as text
%        str2double(get(hObject,'String')) returns contents of p6_editText as a double

%store the contents of input1_editText as a string. if the string
%is not a number then input will be empty
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function p5_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p6_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function p7_editText_Callback(hObject, eventdata, handles)
% hObject    handle to p7_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p7_editText as text
%        str2double(get(hObject,'String')) returns contents of p7_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function p7_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p7_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Pump1_editText_Callback(hObject, eventdata, handles)
% hObject    handle to Pump1_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Pump1_editText as text
%        str2double(get(hObject,'String')) returns contents of Pump1_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function Pump1_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Pump1_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TurbineEff_editText_Callback(hObject, eventdata, handles)
% hObject    handle to TurbineEff_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TurbineEff_editText as text
%        str2double(get(hObject,'String')) returns contents of TurbineEff_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function TurbineEff_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TurbineEff_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function p6_editText_Callback(hObject, eventdata, handles)
% hObject    handle to p6_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p6_editText as text
%        str2double(get(hObject,'String')) returns contents of p6_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function p6_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p6_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function T5_editText_Callback(hObject, eventdata, handles)
% hObject    handle to T5_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of T5_editText as text
%        str2double(get(hObject,'String')) returns contents of T5_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function T5_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to T5_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function axes3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
axes(hObject)
hold on;
%  image(imread('regenerative_diagram.png'))
imshow('regenerative_diagram.png');
set(gca , 'XTick' , [ ]);
set(gca , 'YTick', [ ]);
set(gca , 'ZTick' , [ ]);
% Hint: place code in OpeningFcn to populate axes3
