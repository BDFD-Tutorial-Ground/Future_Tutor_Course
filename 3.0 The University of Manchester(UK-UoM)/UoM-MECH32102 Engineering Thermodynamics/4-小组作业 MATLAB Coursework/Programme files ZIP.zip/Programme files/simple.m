function varargout = simple(varargin)
% SIMPLE MATLAB code for simple.fig
%      SIMPLE, by itself, creates a new SIMPLE or raises the existing
%      singleton*.
%
%      H = SIMPLE returns the handle to a new SIMPLE or the handle to
%      the existing singleton*.
%
%      SIMPLE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SIMPLE.M with the given input arguments.
%
%      SIMPLE('Property','Value',...) creates a new SIMPLE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before simple_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to simple_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help simple

% Last Modified by GUIDE v2.5 06-Sep-2012 11:38:31

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @simple_OpeningFcn, ...
                   'gui_OutputFcn',  @simple_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before simple is made visible.
function simple_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to simple (see VARARGIN)


% Choose default command line output for simple
handles.output = hObject;
%Append a row of results to output_sheet.csv for this calculation
fid = fopen('output_sheet_simple_rankine.csv','w');
fprintf(fid,'p3[kPa],T3[�C],p4[kPa],Qin[kJ/kg],Qout[kJ/kg],WT[kJ/kg],WP[kJ/kg],Efficiency[%%],Quality 4[%%],H1[kJ/kg],H2[kJ/kg],H3[kJ/kg],H4[kJ/kg]\n');
% fprintf(fid,'p3[kPa],T3[�C],p4[kPa],Qin[kJ/kg],Qout[kJ/kg],WT[kJ/kg],WP[kJ/kg],Efficiency[%],Quality 4[%] \n');
fclose(fid);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes simple wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = simple_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in calculate_pushbutton.
function calculate_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to calculate_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% handles.fileName=uigetfile('saturated.xlsx');
p3 = get(handles.p3_editText,'String');
T3 = get(handles.T3_editText,'String');
p4 = get(handles.p4_editText,'String');
PumpEff = get(handles.PumpEff_editText,'String');
TurbineEff = get(handles.TurbineEff_editText,'String');
saturated=xlsread('saturated.xlsx');
% water=xlsread('compressed_water1.xlsx','B2:H10');
% temp_w=[20	40	80	100	140	180	200	220	223.9]';
% pressure_w=[2.5e3 5e3 7.5e3	10e3 15e3 20e3 25e3];
pressure=saturated(:,1);
temp=saturated(:,2);
hf=saturated(:,6);
hfg=saturated(:,7);
hg=saturated(:,8);
sf=saturated(:,9);
sfg=saturated(:,10);
sg1=saturated(:,11);
pressure_super=[0.006112 0.01 0.05 0.1 0.5 0.75	1 1.01325 1.5 2	3 ...
    4	5	6	7	8	9	10	15	20	30	40	50	60	70	80	90	100	...
    110	120	130	140	150	160	170	180	190	200	210	220	221.2]';
Ts=[0.01	7	32.9	45.8	81.3	91.8	99.6	100	111.4	120.2	...
    133.5	143.6	151.8	158.8	165	170.4	175.4	179.9	198.3	212.4	...
    233.8	250.3	263.9	275.6	285.8	295	303.3	311	318	324.6	330.8	...
    336.6	342.1	347.3	352.3	357	361.4	365.7	369.8	373.7	374.15]';
T=[50 100 150 200 250	300	350	375	400	425	450	500	600	700];
hg=[2501	2514	2561	2584	2645	2662	2675	2676	2693	...
    2707	2725	2739	2749	2757	2764	2769	2774	2778	...
    2792	2799	2803	2801	2794	2784	2772	2758	2743	...
    2725	2705	2685	2662	2638	2611	2582	2548	2510	...
    2466	2411	2336	2178	2084]';
sg=[9.155	8.974	8.394	8.149	7.593	7.456	7.359	7.355	7.223	...
    7.127	6.993	6.897	6.822	6.761	6.709	6.663	6.623	6.586	...
    6.445	6.34	6.186	6.07	5.973	5.89	5.814	5.744	5.679	...
    5.615	5.553	5.493	5.433	5.373	5.312	5.248	5.181	5.108	...
    5.027	4.928	4.803	4.552	4.406]';

% Raise an error if p3 is greater than the critical pressure
if str2num(p3) > max(pressure_super)*100
    errmsg = sprintf("Pressures above the critical pressure (%.2f kPa) are not supported.",max(pressure_super)*100);
    f = errordlg(errmsg,"Error",'modal');
    error(errmsg);
end

h_s=xlsread('superheated_h.xlsx','B2:O42');
s_s=xlsread('superheated_s.xlsx','C2:P42');

T31  = interp1(pressure,temp,str2num(p3)/100);
sf31 =interp1(pressure,sf,str2num(p3)/100);
sg31 = interp1(pressure,sg1,str2num(p3)/100);
T4   = interp1(pressure,temp,str2num(p4)/100);
hf4  = interp1(pressure,hf,str2num(p4)/100);
hfg4 = interp1(pressure,hfg,str2num(p4)/100);
sf4  = interp1(pressure,sf,str2num(p4)/100);
sg4  = interp1(pressure,sg1,str2num(p4)/100);
sfg4 = interp1(pressure,sfg,str2num(p4)/100);    
        
% sw_p3 = interp2(temp_w,pressure_w,water',temp_w,p3);
% T2=interp1(sw_p3',temp_w,sf4)+15;

h_p3=interp2(pressure_super,T,h_s',str2num(p3)/100,T);
s_p3=interp2(pressure_super,T,s_s',str2num(p3)/100,T);
Ts_p3=interp1(pressure_super,Ts,str2num(p3)/100);
hg_p3=interp1(pressure_super,hg,str2num(p3)/100);
sg_p3=interp1(pressure_super,sg,str2num(p3)/100);
Tnew=[T Ts_p3];
Tnew=sort(Tnew);

for b=1:length(T)
   if Tnew(b)==Ts_p3
      n=b;
      break;
   end
end

if isnan(h_p3(n))
    h_p3(n)=hg_p3;
    s_p3(n)=sg_p3;
    h_p3(n+1:end+1) = h_p3(n:end);
    h_p3(n+1)=h_p3(n)+(Tnew(n+1)-Tnew(n))*(h_p3(n+2)-h_p3(n))/(Tnew(n+2)-Tnew(n));
    s_p3(n+1:end+1) = s_p3(n:end);
    s_p3(n+1)=s_p3(n)+(Tnew(n+1)-Tnew(n))*(s_p3(n+2)-s_p3(n))/(Tnew(n+2)-Tnew(n));
else
    h_p3(n+1:end+1) = h_p3(n:end);
    h_p3(n)=hg_p3;
    s_p3(n+1:end+1) = s_p3(n:end);
    s_p3(n)=sg_p3;
end

% raise a warning if our T3 is below the saturation temperature at that
% pressure
if str2num(T3) < Ts_p3
    errmsg = sprintf("T3 is below the saturation temperature (%3.2f C) at this pressure (%.2f kPa).",Ts_p3,str2num(p3));
    f = errordlg(errmsg,"Warning",'modal');
    %error(errmsg);
end
% replace invalid values
idxgood=~(isnan(h_p3) | isnan(s_p3));
h_p3=h_p3(idxgood);
s_p3=s_p3(idxgood);
Tnew=Tnew(idxgood);

h3=interp1(Tnew,h_p3,str2num(T3),'linear','extrap');
s3=interp1(Tnew,s_p3,str2num(T3),'linear','extrap');
p1=str2num(p4);
% T1=T6;
h1=hf4;
p2=str2num(p3);
s4=s3;
x4=(s4-sf4)/sfg4;
h4=hf4+x4*hfg4;
% h2=h1+0.001*(p2-p1);
pump=str2num(PumpEff)*0.01;
turbine=str2num(TurbineEff)*0.01;
% total = str2num(p3) + str2num(T3);
% c = num2str(total);
WT=sprintf('%0.2f',(h3-h4)*str2num(TurbineEff)*0.01);
WP=sprintf('%0.2f',-(0.001*(p2-p1))/(str2num(PumpEff)*0.01));
h4new=h3-(h3-h4)*str2num(TurbineEff)*0.01;
h2=h1+(0.001*(p2-p1))/(str2num(PumpEff)*0.01);
x4new=(h4new-hf4)/hfg4;
Qin=sprintf('%0.2f',h3-h2);
Qout=sprintf('%0.2f',h1-h4new);
Quality=sprintf('%0.2f',x4new*100);
W=sprintf('%0.2f',(h3-h4)*str2num(TurbineEff)*0.01-(0.001*(p2-p1))/(str2num(PumpEff)*0.01));  %WT+WP
Eff=sprintf('%0.2f',((h3-h4)*str2num(TurbineEff)*0.01-(0.001*(p2-p1))/(str2num(PumpEff)*0.01))*100/(h3-h2));   %W*100/Qin

% Qin=num2str(h3-h2);
% Qout=num2str(h1-h4);
% WT=num2str(h3-h4);
% WP=num2str(h1-h2);
% Quality=num2str(x4*100);
% W=num2str(h3-h4+h1-h2);  %WT+WP
% Eff=num2str((h3-h4+h1-h2)*100/(h3-h2));   %W*100/Qin
% need to convert the answer back into String type to display it
set(handles.Qin_staticText,'String',Qin);
set(handles.Qout_text,'String',Qout);
set(handles.WT_text,'String',WT);
set(handles.WP_text,'String',WP);
set(handles.Eff_text,'String',Eff);
set(handles.Quality_text,'String',Quality);
axes(handles.axes2);
% plot(handles.axes2,sf,temp,'k');
% hold on;
% plot(handles.axes2,sg1,temp,'k');
plot(sf,temp,'k');
hold on;
plot(sg1,temp,'k');
xlabel('Entropy, s(kJ/kgK)');
ylabel(['Temperature (' 176 'C)']);
plot([sf4 sg4],[T4 T4],'LineWidth',2);
plot([sf4 sf4],[T4 T4+30],'-o','LineWidth',2);
if pump~=1
plot([sf4 (sf4+sfg4*(1-pump)-0.5)],[T4 T4+125],'-.or','LineWidth',2);
end
plot([sf31 sg31],[T31 T31],'LineWidth',2);
plot([s3 s3],[T4 str2num(T3)],'-o','LineWidth',2);
if turbine~=1
plot([sf4+x4new*sfg4 s3],[T4 str2num(T3)],'-.or','LineWidth',2);
end
plot([0.5*(sg31+s3) s3],[0.25*(3*T31+str2num(T3)) str2num(T3)],':','LineWidth',2);
plot([sf4 sf31],[T4+30 T31],'LineWidth',2);
x=[sg31 0.5*(sg31+s3) s3];
y=[T31 0.25*(3*T31+str2num(T3)) str2num(T3)];
coef=polyfit(x,y,2);
y1 = polyval(coef, x);
plot(x,y1,':','LineWidth',2);
hold off;
H1=num2str(h1);
H2=num2str(h2);
H3=num2str(h3);
H4=num2str(h4new);
%Append a row of results to output_sheet.csv for this calculation
fid = fopen('output_sheet_simple_rankine.csv','a+');
fprintf(fid, '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',p3,T3,p4,Qin,Qout,WT,WP,Eff,Quality,H1,H2,H3,H4);
fclose(fid);
guidata(hObject, handles);

function p3_editText_Callback(hObject, eventdata, handles)
% hObject    handle to p3_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p3_editText as text
%        str2double(get(hObject,'String')) returns contents of p3_editText as a double

%store the contents of input1_editText as a string. if the string
%is not a number then input will be empty
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function p3_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p3_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function T3_editText_Callback(hObject, eventdata, handles)
% hObject    handle to T3_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of T3_editText as text
%        str2double(get(hObject,'String')) returns contents of T3_editText as a double

%store the contents of input1_editText as a string. if the string
%is not a number then input will be empty
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function T3_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to T3_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function p4_editText_Callback(hObject, eventdata, handles)
% hObject    handle to p4_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p4_editText as text
%        str2double(get(hObject,'String')) returns contents of p4_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function p4_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p4_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PumpEff_editText_Callback(hObject, eventdata, handles)
% hObject    handle to PumpEff_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PumpEff_editText as text
%        str2double(get(hObject,'String')) returns contents of PumpEff_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function PumpEff_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PumpEff_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TurbineEff_editText_Callback(hObject, eventdata, handles)
% hObject    handle to TurbineEff_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TurbineEff_editText as text
%        str2double(get(hObject,'String')) returns contents of TurbineEff_editText as a double
input = str2num(get(hObject,'String'));
%checks to see if input is empty. if so, default input1_editText to zero
if (isempty(input))
set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function TurbineEff_editText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TurbineEff_editText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.


% --- Executes on button press in Results_pushbutton.
function Results_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to Results_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function axes3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% axes(hObject)
% imshow('simple_diagram.png')
axes(hObject)
hold on;
image(imread('simple_diagram.png'))
set(gca , 'XTick' , [ ]);
set(gca , 'YTick', [ ]);
set(gca , 'ZTick' , [ ]);
% Hint: place code in OpeningFcn to populate axes3
